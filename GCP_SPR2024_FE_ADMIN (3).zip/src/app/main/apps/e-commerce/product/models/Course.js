export const COURSE_EMPTY = {
    "name": "",
    "duration": 0,
    "imgUrl": "",
    "status": "",
    "age": "",
    "projectId": "",
    "description": "",
    "income": "",
    "outcome": "",
    "courseModules": [
      {
        "description": "",
        "title": "",
        "moduleLessons": [
          {
            "description": "",
            "title": "",
            "isLock": true,
            "lessonDocuments": [
              {
                "description": "",
                "documentUrl": "",
                "title": ""
              }
            ],
            "lessonQuizzes": [
              {
                "duration": 0,
                "title": "",
                "isPass": false
              }
            ]
          }
        ]
      }
    ],
    "courseCoursePackages": [
      {
        "name": "",
        "maxStudent": 0,
        "price": 0
      }
    ]
  }
    