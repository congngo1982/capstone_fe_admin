import { createContext } from 'react';
/**
 * The AppContext object.
 */
const AppContext = createContext({ routes: [] });
export default AppContext;
